'use client'

import { ScrollProgress } from '@/components/portfolio/scroll-progress'
import { SiteNav } from '@/components/portfolio/site-nav'
import { Hero } from '@/components/portfolio/hero'
import { ManifestMarquee } from '@/components/portfolio/manifest-marquee'
import { Origin } from '@/components/portfolio/origin'
import { Journey } from '@/components/portfolio/journey'
import { Craft } from '@/components/portfolio/craft'
import { Leadership } from '@/components/portfolio/leadership'
import { Creations } from '@/components/portfolio/creations'
import { Horizon } from '@/components/portfolio/horizon'
import { Connect } from '@/components/portfolio/connect'
import { SiteFooter } from '@/components/portfolio/site-footer'

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <ScrollProgress />
      <SiteNav />
      <main className="flex-1">
        <Hero />
        <ManifestMarquee />
        <Origin />
        <Journey />
        <Craft />
        <Leadership />
        <Creations />
        <Horizon />
        <Connect />
      </main>
      <SiteFooter />
    </div>
  )
}
