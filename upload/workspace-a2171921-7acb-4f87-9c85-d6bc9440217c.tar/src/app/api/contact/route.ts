import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const schema = z.object({
  name: z.string().min(2, 'Name is too short').max(80),
  email: z.string().email('A valid email is required').max(120),
  role: z.string().max(80).optional().nullable(),
  intent: z.string().max(80).optional().nullable(),
  message: z.string().min(10, 'Tell me a little more').max(2000),
})

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const parsed = schema.safeParse(body)

    if (!parsed.success) {
      const first = parsed.error.issues[0]
      return NextResponse.json(
        { ok: false, error: first?.message ?? 'Invalid input' },
        { status: 400 },
      )
    }

    const { name, email, role, intent, message } = parsed.data

    const record = await db.contactMessage.create({
      data: {
        name,
        email,
        role: role ?? null,
        intent: intent ?? null,
        message,
      },
    })

    return NextResponse.json({ ok: true, id: record.id })
  } catch (err) {
    console.error('[contact] error', err)
    return NextResponse.json(
      { ok: false, error: 'Something went wrong on my end. Please try again.' },
      { status: 500 },
    )
  }
}
