/**
 * ─────────────────────────────────────────────────────────────
 *  THE BUILDER'S DAWN — Portfolio content
 *  Every word here is a story beat, not a bullet point.
 *  (Customize freely — name, links, and details are all here.)
 * ─────────────────────────────────────────────────────────────
 */

export const identity = {
  name: "Yusuf",
  fullName: "Yusuf Abdullahi",
  role: "Information Systems Student · Builder · Community Leader",
  university: "Hawassa University",
  location: "Hawassa, Ethiopia",
  field: "Information Systems",
  email: "hello@yusuf.dev",
  tagline: "A young builder evolving through technology, leadership, creativity, and community.",
};

export type Chapter = {
  id: string;
  index: string;
  title: string;
  label: string;
};

export const chapters: Chapter[] = [
  { id: "dawn", index: "00", title: "Dawn", label: "The opening" },
  { id: "origin", index: "I", title: "Origin", label: "Where I'm from" },
  { id: "journey", index: "II", title: "Journey", label: "The path so far" },
  { id: "craft", index: "III", title: "Craft", label: "Tools of the trade" },
  { id: "leadership", index: "IV", title: "Leadership", label: "Building people" },
  { id: "creations", index: "V", title: "Creations", label: "What I've built" },
  { id: "horizon", index: "VI", title: "Horizon", label: "Where I'm going" },
  { id: "connect", index: "VII", title: "Connect", label: "Let's build" },
];

export const hero = {
  eyebrow: "Chapter Zero",
  kicker: "The Builder's Dawn",
  headlineLines: [
    "I build things",
    "that bring",
    "people together.",
  ],
  lede:
    "An Information Systems student at Hawassa University, working where technology meets community, story, and leadership. This isn't a résumé. It's a record of becoming.",
  stats: [
    { value: "IS", label: "Information Systems, in progress" },
    { value: "Head of PR", label: "Leading communications at Peak Craft" },
    { value: "800+", label: "Members served by PCIC, the platform I'm building" },
  ],
};

export const origin = {
  eyebrow: "Chapter I · Origin",
  title: "I work at the intersection of four currents.",
  body: [
    "Most people pick a lane. I never could. Technology pulled me toward systems and logic. Community pulled me toward people. Public relations pulled me toward narrative. Content creation pulled me toward craft.",
    "For a long time I treated these as separate interests. Then I realized they were the same skill viewed from different angles — the skill of taking something abstract and making it real, useful, and felt by others.",
    "That's the throughline of everything on this page. I'm not a developer who also does PR, or a PR person who also codes. I'm a builder — and building, for me, means shaping both the product and the story around it.",
  ],
  currents: [
    {
      name: "Technology",
      glyph: "◆",
      desc: "Systems, code, infrastructure. The logic layer of every impact I want to make.",
    },
    {
      name: "Community",
      glyph: "✦",
      desc: "People are not users to me — they are the reason anything gets built at all.",
    },
    {
      name: "Public Relations",
      glyph: "❖",
      desc: "How an idea travels from one mind to many. Strategy, voice, and trust.",
    },
    {
      name: "Creation",
      glyph: "✧",
      desc: "Design, video, words. The craft of making the invisible visible.",
    },
  ],
  principles: [
    {
      title: "Discipline over motivation",
      desc: "Motivation is weather. Discipline is geography. I build on geography.",
    },
    {
      title: "Faith as a compass",
      desc: "Islamic values keep the work honest, the ambition measured, and the intent clean.",
    },
    {
      title: "Build in public",
      desc: "If it isn't shared, it didn't happen. Growth is a public act.",
    },
    {
      title: "Leave the ladder down",
      desc: "Every step I climb, I reach back. Community is not a side project.",
    },
    {
      title: "Systems beat hustle",
      desc: "I'd rather design a process that runs without me than be the process.",
    },
    {
      title: "Curiosity is the engine",
      desc: "I'm a student by title and by nature. The learning never clocks out.",
    },
  ],
};

export type Milestone = {
  year: string;
  phase: string;
  title: string;
  story: string;
  beat: "spark" | "build" | "lead" | "ship" | "learn";
};

export const journey: Milestone[] = [
  {
    year: "First spark",
    phase: "The beginning",
    title: "The first line of code",
    story:
      "It started with HTML and CSS — not as a subject, but as a way to make something exist where nothing had before. A blank page became a page with presence. I was hooked on that feeling: the moment the invisible becomes visible.",
    beat: "spark",
  },
  {
    year: "Early craft",
    phase: "Building the base",
    title: "JavaScript, C++, and the habit of finishing",
    story:
      "I stopped collecting languages and started finishing things. JavaScript taught me interactivity. C++ taught me rigor and patience. Databases and Git taught me that real work is structured, versioned, and recoverable. The lesson: a finished small thing beats a perfect imagined one.",
    beat: "build",
  },
  {
    year: "The turn",
    phase: "Stepping up",
    title: "Head of PR at Peak Craft",
    story:
      "I was offered a role that had nothing to do with code and everything to do with people. Leading PR meant owning the voice of a community — strategy, content, events, coordination. It taught me that leadership is a technical skill, and that story is infrastructure.",
    beat: "lead",
  },
  {
    year: "The build",
    phase: "Shipping real systems",
    title: "Android-Based Student Debt Repayment & Tracking System",
    story:
      "A problem that mattered: students juggling debt with no clean way to track or repay it. I designed and built an Android system to make that manageable. It was the first time I saw code relieve a real, daily pressure for real people. That changed what I wanted to build.",
    beat: "ship",
  },
  {
    year: "Now",
    phase: "Leveling up",
    title: "The full-stack pursuit",
    story:
      "Today I'm learning React, Next.js, and MongoDB — and applying it in real time to PCIC, a live platform serving 800+ members of my community. Docker and Linux keep the foundation solid. The goal is no longer to prove I can code. It's to build things that compound.",
    beat: "learn",
  },
];

export type CraftGroup = {
  name: string;
  glyph: string;
  desc: string;
  tools: { name: string; note: string }[];
};

export const craft: CraftGroup[] = [
  {
    name: "Engineering",
    glyph: "◆",
    desc: "The systems layer. Where ideas become runnable.",
    tools: [
      { name: "HTML / CSS", note: "Structure & presence" },
      { name: "JavaScript", note: "Interactivity" },
      { name: "C++", note: "Rigor & fundamentals" },
      { name: "React", note: "Component thinking, learning" },
      { name: "Next.js", note: "Full-stack frames, learning" },
      { name: "MongoDB", note: "Document data, learning" },
      { name: "Databases", note: "Modeling the real world" },
      { name: "Git", note: "History & collaboration" },
      { name: "Docker", note: "Reproducible environments" },
      { name: "Linux", note: "Comfort in the terminal" },
    ],
  },
  {
    name: "Creative",
    glyph: "✧",
    desc: "The craft layer. Where systems become felt.",
    tools: [
      { name: "Graphic design", note: "Visual identity" },
      { name: "Video editing", note: "Pacing & narrative" },
      { name: "Storytelling", note: "Making meaning land" },
      { name: "Content creation", note: "Consistent output" },
    ],
  },
  {
    name: "Leadership",
    glyph: "❖",
    desc: "The people layer. Where output becomes impact.",
    tools: [
      { name: "Team coordination", note: "Aligning many toward one" },
      { name: "Event promotion", note: "Turning plans into presence" },
      { name: "Community engagement", note: "Earning attention, repeatedly" },
      { name: "PR strategy", note: "Voice, trust, reach" },
    ],
  },
  {
    name: "Communication",
    glyph: "✦",
    desc: "The bridge layer. Where work meets the world.",
    tools: [
      { name: "Social media management", note: "Channels as systems" },
      { name: "Public relations", note: "Reputation as a product" },
      { name: "Copywriting", note: "Clarity under constraint" },
      { name: "Cross-team liaison", note: "Translating between worlds" },
    ],
  },
];

export const leadership = {
  eyebrow: "Chapter IV · Leadership",
  org: "Peak Craft",
  role: "Head of Public Relations",
  duration: "Current",
  intro:
    "Leading PR at Peak Craft is the role that reshaped how I think about impact. Code builds features. PR builds the bridge between a feature and the people it's for. I own that bridge end to end.",
  pillars: [
    {
      title: "Social media strategy",
      desc: "Designing the channel mix, cadence, and voice — turning scattered posting into a coherent system people can recognize.",
      metric: "Owned",
    },
    {
      title: "Content creation",
      desc: "Writing, designing, and producing the assets. Strategy is cheap; consistent output is the actual job.",
      metric: "Daily",
    },
    {
      title: "Community engagement",
      desc: "Showing up in replies, DMs, and conversations. Communities die when the people behind the brand go silent.",
      metric: "Always-on",
    },
    {
      title: "Event promotion",
      desc: "Turning an event from a date on a calendar into something people feel they'd be missing out on.",
      metric: "Per launch",
    },
    {
      title: "Team coordination",
      desc: "Aligning designers, creators, and organizers behind one message. The unglamorous work that makes everything else land.",
      metric: "Continuous",
    },
  ],
  reflection:
    "The biggest lesson: a leader's job isn't to be the most talented person in the room. It's to make the room more talented than it would be without them.",
};

export type Project = {
  id: string;
  name: string;
  category: string;
  year: string;
  status: "Shipped" | "Ongoing" | "Concept";
  featured: boolean;
  summary: string;
  problem: string;
  approach: string;
  impact: string;
  stack: string[];
  glyph: string;
  links?: { label: string; href: string; kind: 'live' | 'projects' }[];
};

export const projects: Project[] = [
  {
    id: "pcic",
    name: "PCIC Internal Management System",
    category: "Web Platform · Community Systems",
    year: "2024 — Present",
    status: "Ongoing",
    featured: true,
    summary:
      "A web platform digitizing membership tracking, event attendance, leadership decisions, and disciplinary workflows for the Peak Craft Informatics Community — 800+ members across IS, CS, and IT at Hawassa University.",
    problem:
      "A community of 800+ members spanning Information Systems, Computer Science, and IT was running on spreadsheets, paper, and memory. Membership records drifted, event attendance was manual, leadership decisions weren't logged, and disciplinary workflows lived in scattered inboxes. The administrative friction was quietly draining the community's energy — exactly the kind of work that should disappear into a system.",
    approach:
      "I'm building PCIC as a web platform that digitizes the community's core operations: a live membership registry, event attendance tracking, leadership decision logs, and structured disciplinary workflows. It's designed for the people who run the community, not just the members — clear records, auditable processes, less paperwork, more community.",
    impact:
      "Turns a community of 800+ into a managed organization with a single source of truth. Live at pcic.tech — and it's the same community I lead PR for, which means I'm not just telling its story, I'm building the system that runs it.",
    stack: ["Next.js", "React", "TypeScript", "MongoDB", "Tailwind"],
    glyph: "⬡",
    links: [
      { label: "Live platform", href: "https://pcic.tech", kind: "live" },
      { label: "Peak Projects", href: "https://pcic.tech/peak-projects", kind: "projects" },
    ],
  },
  {
    id: "debt-tracker",
    name: "Student Debt Repayment & Tracking System",
    category: "Android · Systems",
    year: "2024",
    status: "Shipped",
    featured: false,
    summary:
      "An Android application that lets students track, manage, and repay debts without the chaos of memory or paper.",
    problem:
      "Students carried debt in their heads — amounts, deadlines, who owed whom. It created stress, missed payments, and broken trust. There was no system, and memory is a terrible system.",
    approach:
      "I designed a mobile-first tracking system: clear balances, repayment scheduling, and a ledger that turned ambiguity into a single source of truth. Built for the device students already carry everywhere.",
    impact:
      "Turned an invisible, anxiety-driving burden into a calm, checkable dashboard. Proof that a small system can quietly improve daily life for many people.",
    stack: ["Android", "Java", "SQLite", "UI Design"],
    glyph: "◈",
  },
  {
    id: "web-projects",
    name: "Web Development Projects",
    category: "Web · Frontend",
    year: "Ongoing",
    status: "Ongoing",
    featured: false,
    summary:
      "A steady output of websites and interfaces — practice that compounds into instinct.",
    problem:
      "Knowing HTML, CSS, and JavaScript in isolation is different from shipping a real interface that real people use. The gap only closes by building.",
    approach:
      "I treat every web project as a rep: structure, style, interactivity, deployment. Each one teaches a specific lesson I couldn't have read my way into.",
    impact:
      "A growing portfolio of shipped interfaces and a sharpened instinct for layout, state, and user flow.",
    stack: ["HTML", "CSS", "JavaScript", "Git"],
    glyph: "▲",
  },
  {
    id: "community",
    name: "Community-Driven Initiatives",
    category: "Community · Impact",
    year: "Ongoing",
    status: "Ongoing",
    featured: false,
    summary:
      "Initiatives that exist not for a grade or a client, but because a community needed them to exist.",
    problem:
      "Communities have needs that no individual owns. Without someone stepping up to organize, the need just sits there.",
    approach:
      "I show up as the organizer — the person who turns 'someone should' into 'here's the plan.' Part technology, part logistics, entirely about people.",
    impact:
      "Moments where a group of people moved together on something that mattered. The kind of impact that doesn't fit on a résumé but defines one.",
    stack: ["Organization", "PR", "Events", "Coordination"],
    glyph: "✦",
  },
  {
    id: "university",
    name: "University Projects",
    category: "Academic · Applied",
    year: "Ongoing",
    status: "Ongoing",
    featured: false,
    summary:
      "Coursework treated as real engineering problems, not boxes to check.",
    problem:
      "Academic projects often die the moment they're graded. I treat them as chances to build something I'd actually use.",
    approach:
      "Each project gets the full treatment — proper planning, clean structure, documentation. The grade is a byproduct; the skill is the point.",
    impact:
      "A body of work that doubles as a portfolio and a record of how my thinking has matured project over project.",
    stack: ["IS Curriculum", "Systems", "Databases", "Documentation"],
    glyph: "❖",
  },
];

export const horizon = {
  eyebrow: "Chapter VI · Horizon",
  title: "I'm not chasing a job title. I'm building a trajectory.",
  intro:
    "Here's the honest map of where I am and where I'm pointed. It will change — that's the point of having a map instead of a destination.",
  nowLearning: [
    { name: "React", note: "Thinking in components & state" },
    { name: "Next.js", note: "Full-stack, server & client together" },
    { name: "MongoDB", note: "Flexible, document-shaped data" },
    { name: "Full-stack development", note: "Owning the whole loop" },
  ],
  vision: [
    {
      role: "A builder",
      desc: "Someone who ships. Not someday — continuously. The proof is in the things that exist because I made them exist.",
    },
    {
      role: "A leader",
      desc: "Not the loudest voice, but the one who makes the team louder and sharper than the sum of its members.",
    },
    {
      role: "A creator",
      desc: "Stories, designs, systems, content. A creator doesn't wait for permission — they make and share.",
    },
    {
      role: "A technology professional",
      desc: "Deep enough to be trusted, broad enough to connect the dots others miss.",
    },
    {
      role: "A community builder",
      desc: "Building systems is satisfying. Building communities that build systems is the real game.",
    },
    {
      role: "A storyteller of impact",
      desc: "Technology + storytelling is the multiplier. I want every system I build to come with a story that makes it reach further.",
    },
  ],
  closing:
    "The long game is to combine technology and storytelling to create impact that outlasts me. The short game is the next thing I ship — which is already underway.",
};

export const connect = {
  eyebrow: "Chapter VII · Connect",
  title: "If something here resonates, let's build.",
  intro:
    "I'm open to collaboration, opportunities, mentorship, and good conversation. Whether you're a recruiter, a founder, a fellow student, or just curious — the door is open.",
  email: "hello@yusuf.dev",
  socials: [
    { label: "GitHub", handle: "@the-builder", href: "#" },
    { label: "LinkedIn", handle: "Yusuf Abdullahi", href: "#" },
    { label: "X / Twitter", handle: "@the_builder", href: "#" },
    { label: "Telegram", handle: "@yusuf_builds", href: "#" },
  ],
};

export const manifest = [
  "Curiosity",
  "Growth",
  "Leadership",
  "Creativity",
  "Discipline",
  "Community",
  "Craft",
  "Impact",
];
