'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, Sunrise } from 'lucide-react'
import { cn } from '@/lib/utils'
import { chapters, identity } from '@/lib/portfolio-data'
import { ThemeToggle } from './theme-toggle'

function useActiveSection() {
  const [active, setActive] = React.useState(chapters[0].id)
  React.useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)
        if (visible[0]) setActive(visible[0].target.id)
      },
      { rootMargin: '-40% 0px -55% 0px', threshold: [0, 0.25, 0.5, 1] },
    )
    chapters.forEach((c) => {
      const el = document.getElementById(c.id)
      if (el) observer.observe(el)
    })
    return () => observer.disconnect()
  }, [])
  return active
}

export function SiteNav() {
  const [scrolled, setScrolled] = React.useState(false)
  const [mobileOpen, setMobileOpen] = React.useState(false)
  const active = useActiveSection()

  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const go = (id: string) => {
    setMobileOpen(false)
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <>
      <header
        className={cn(
          'fixed inset-x-0 top-0 z-50 transition-all duration-500',
          scrolled
            ? 'border-b border-border/60 bg-background/80 backdrop-blur-xl'
            : 'border-b border-transparent bg-transparent',
        )}
      >
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:px-8">
          {/* Brand */}
          <button
            onClick={() => go('dawn')}
            className="group flex items-center gap-2.5"
            aria-label="Back to top"
          >
            <span className="relative flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary ring-1 ring-primary/30">
              <Sunrise className="h-4 w-4" />
              <span className="absolute inset-0 rounded-full bg-primary/20 blur-md animate-dawn-pulse" />
            </span>
            <span className="hidden flex-col leading-none sm:flex">
              <span className="font-display text-sm font-semibold tracking-tight">
                The Builder&apos;s Dawn
              </span>
              <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                {identity.name} · {identity.field}
              </span>
            </span>
          </button>

          {/* Desktop chapter links */}
          <nav className="hidden items-center gap-1 lg:flex">
            {chapters.slice(1, 7).map((c) => (
              <button
                key={c.id}
                onClick={() => go(c.id)}
                className={cn(
                  'relative rounded-full px-3 py-1.5 font-mono text-xs uppercase tracking-[0.12em] transition-colors',
                  active === c.id
                    ? 'text-primary'
                    : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {active === c.id && (
                  <motion.span
                    layoutId="nav-pill"
                    className="absolute inset-0 -z-10 rounded-full bg-primary/10 ring-1 ring-primary/25"
                    transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                  />
                )}
                {c.title}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={() => go('connect')}
              className="hidden rounded-full bg-primary px-4 py-2 text-xs font-medium uppercase tracking-[0.14em] text-primary-foreground transition-transform hover:scale-[1.03] active:scale-95 sm:inline-flex"
            >
              Let&apos;s build
            </button>
            <ThemeToggle />
            <button
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-border/70 text-foreground lg:hidden"
              onClick={() => setMobileOpen((v) => !v)}
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 lg:hidden"
          >
            <div
              className="absolute inset-0 bg-background/90 backdrop-blur-xl"
              onClick={() => setMobileOpen(false)}
            />
            <motion.nav
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              transition={{ delay: 0.05 }}
              className="relative mx-auto mt-20 flex max-w-md flex-col gap-1 px-6"
            >
              {chapters.map((c) => (
                <button
                  key={c.id}
                  onClick={() => go(c.id)}
                  className={cn(
                    'group flex items-baseline justify-between border-b border-border/50 py-4 text-left transition-colors',
                    active === c.id ? 'text-primary' : 'text-foreground',
                  )}
                >
                  <span className="font-display text-2xl font-semibold">{c.title}</span>
                  <span className="font-mono text-xs text-muted-foreground">
                    {c.index} · {c.label}
                  </span>
                </button>
              ))}
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Desktop vertical chapter rail */}
      <div className="pointer-events-none fixed right-6 top-1/2 z-40 hidden -translate-y-1/2 xl:block">
        <ul className="pointer-events-auto flex flex-col gap-1">
          {chapters.map((c) => (
            <li key={c.id}>
              <button
                onClick={() => go(c.id)}
                className="group flex items-center justify-end gap-3"
                aria-label={`Go to ${c.title}`}
              >
                <span
                  className={cn(
                    'font-mono text-[10px] uppercase tracking-[0.18em] opacity-0 transition-opacity group-hover:opacity-100',
                    active === c.id ? 'text-primary opacity-100' : 'text-muted-foreground',
                  )}
                >
                  {c.title}
                </span>
                <span
                  className={cn(
                    'h-8 w-px transition-all duration-300',
                    active === c.id
                      ? 'bg-primary'
                      : 'bg-border group-hover:bg-primary/40',
                  )}
                />
              </button>
            </li>
          ))}
        </ul>
      </div>
    </>
  )
}
