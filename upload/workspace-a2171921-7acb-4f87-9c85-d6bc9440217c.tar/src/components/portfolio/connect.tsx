'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Loader2, Send, Mail, ArrowUpRight } from 'lucide-react'
import { toast } from 'sonner'
import { connect, identity } from '@/lib/portfolio-data'
import { SectionHeading } from './section-heading'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

const schema = z.object({
  name: z.string().min(2, 'Tell me your name'),
  email: z.string().email('A valid email, please'),
  role: z.string().optional(),
  intent: z.string().optional(),
  message: z.string().min(10, 'A sentence or two more').max(2000),
})

type FormValues = z.infer<typeof schema>

const intents = [
  'Collaboration',
  'Opportunity',
  'Mentorship',
  'Project / freelance',
  'Just saying hello',
]

export function Connect() {
  const [submitting, setSubmitting] = React.useState(false)

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { name: '', email: '', role: '', intent: '', message: '' },
  })

  async function onSubmit(values: FormValues) {
    setSubmitting(true)
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        throw new Error(data.error ?? 'Failed to send')
      }
      toast.success('Message received.', {
        description: "Thanks for reaching out — I'll reply soon.",
      })
      form.reset()
    } catch (err) {
      toast.error('Could not send message', {
        description: err instanceof Error ? err.message : 'Please try again.',
      })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <section id="connect" className="relative scroll-mt-20 py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading index="VII" eyebrow="Connect" title={connect.title} />
        <p className="mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
          {connect.intro}
        </p>

        <div className="mt-12 grid gap-10 lg:grid-cols-[1fr_1.2fr] lg:gap-16">
          {/* Left — direct channels */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <a
              href={`mailto:${connect.email}`}
              className="group flex items-center gap-4 rounded-2xl border border-border/60 bg-card/50 p-5 transition-colors hover:border-primary/40"
            >
              <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary ring-1 ring-primary/25">
                <Mail className="h-5 w-5" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                  Email
                </div>
                <div className="truncate font-display text-base font-semibold">
                  {connect.email}
                </div>
              </div>
              <ArrowUpRight className="h-4 w-4 text-muted-foreground transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary" />
            </a>

            <div className="rounded-2xl border border-border/60 bg-card/50 p-5">
              <div className="mb-4 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                Find me elsewhere
              </div>
              <div className="grid grid-cols-2 gap-3">
                {connect.socials.map((s) => (
                  <a
                    key={s.label}
                    href={s.href}
                    className="group flex flex-col rounded-xl border border-border/50 bg-background/50 p-4 transition-colors hover:border-primary/40 hover:bg-accent/30"
                  >
                    <span className="font-display text-sm font-semibold">{s.label}</span>
                    <span className="mt-0.5 truncate font-mono text-[11px] text-muted-foreground">
                      {s.handle}
                    </span>
                  </a>
                ))}
              </div>
            </div>

            <div className="rounded-2xl border border-primary/20 bg-primary/5 p-5">
              <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-primary">
                Based in
              </div>
              <div className="mt-1 font-display text-lg font-semibold">{identity.location}</div>
              <div className="text-sm text-muted-foreground">{identity.university}</div>
            </div>
          </motion.div>

          {/* Right — form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="rounded-3xl border border-border/60 bg-card p-6 sm:p-8"
          >
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                <div className="grid gap-5 sm:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono text-xs uppercase tracking-[0.14em]">
                          Your name
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Who am I talking to?"
                            className="h-11 bg-background"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono text-xs uppercase tracking-[0.14em]">
                          Email
                        </FormLabel>
                        <FormControl>
                          <Input
                            type="email"
                            placeholder="you@somewhere.com"
                            className="h-11 bg-background"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid gap-5 sm:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono text-xs uppercase tracking-[0.14em]">
                          You are a… <span className="text-muted-foreground">(optional)</span>
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Recruiter, founder, student…"
                            className="h-11 bg-background"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="intent"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono text-xs uppercase tracking-[0.14em]">
                          What&apos;s this about?
                        </FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="h-11 bg-background">
                              <SelectValue placeholder="Pick one" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {intents.map((i) => (
                              <SelectItem key={i} value={i}>
                                {i}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono text-xs uppercase tracking-[0.14em]">
                        Your message
                      </FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="What's on your mind?"
                          className="min-h-[140px] resize-none bg-background"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  disabled={submitting}
                  className="h-11 w-full gap-2 rounded-full bg-primary text-primary-foreground"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" /> Sending…
                    </>
                  ) : (
                    <>
                      Send message <Send className="h-4 w-4" />
                    </>
                  )}
                </Button>
              </form>
            </Form>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
