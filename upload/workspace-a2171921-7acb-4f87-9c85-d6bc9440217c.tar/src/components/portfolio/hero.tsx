'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import { ArrowDown, MapPin } from 'lucide-react'
import { hero, identity } from '@/lib/portfolio-data'

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12, delayChildren: 0.1 } },
}
const item = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } },
}

export function Hero() {
  return (
    <section
      id="dawn"
      className="grain-overlay relative flex min-h-[100svh] flex-col justify-center overflow-hidden pt-20"
    >
      {/* Atmospheric dawn background */}
      <div className="absolute inset-0 -z-10">
        <img
          src="/visuals/hero-dawn.png"
          alt=""
          aria-hidden
          className="h-full w-full object-cover opacity-40 dark:opacity-55"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/60 to-background" />
        <div className="absolute inset-0 dawn-glow" />
      </div>

      <div className="mx-auto w-full max-w-6xl px-5 sm:px-8">
        <motion.div variants={container} initial="hidden" animate="show" className="max-w-4xl">
          <motion.div variants={item} className="mb-8 flex flex-wrap items-center gap-x-4 gap-y-2 font-mono text-xs uppercase tracking-[0.22em] text-muted-foreground">
            <span className="text-primary">{hero.eyebrow}</span>
            <span className="h-px w-8 bg-primary/40" />
            <span>{hero.kicker}</span>
            <span className="h-px w-8 bg-primary/40" />
            <span className="inline-flex items-center gap-1.5">
              <MapPin className="h-3 w-3" /> {identity.location}
            </span>
          </motion.div>

          <h1 className="font-display text-[2.7rem] font-semibold leading-[0.98] tracking-tight text-balance sm:text-7xl lg:text-8xl">
            {hero.headlineLines.map((line, i) => (
              <motion.span
                key={i}
                variants={item}
                className={i === 0 ? 'block' : 'block'}
              >
                {i === hero.headlineLines.length - 1 ? (
                  <span className="relative inline-block">
                    <span className="bg-gradient-to-r from-primary via-primary to-primary/60 bg-clip-text text-transparent">
                      {line}
                    </span>
                    <motion.span
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: 1 }}
                      transition={{ delay: 0.9, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
                      className="absolute -bottom-1 left-0 h-[3px] w-full origin-left rounded-full bg-primary/70"
                    />
                  </span>
                ) : (
                  line
                )}
              </motion.span>
            ))}
          </h1>

          <motion.p
            variants={item}
            className="mt-8 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg"
          >
            {hero.lede}
          </motion.p>

          <motion.div variants={item} className="mt-10 flex flex-wrap items-center gap-3">
            <button
              onClick={() => document.getElementById('creations')?.scrollIntoView({ behavior: 'smooth' })}
              className="group inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-transform hover:scale-[1.03] active:scale-95"
            >
              See what I&apos;ve built
              <ArrowDown className="h-4 w-4 transition-transform group-hover:translate-y-0.5" />
            </button>
            <button
              onClick={() => document.getElementById('origin')?.scrollIntoView({ behavior: 'smooth' })}
              className="inline-flex items-center gap-2 rounded-full border border-border bg-background/50 px-6 py-3 text-sm font-medium text-foreground backdrop-blur transition-colors hover:border-primary/50 hover:text-primary"
            >
              Start the journey
            </button>
          </motion.div>

          {/* Stats */}
          <motion.dl
            variants={item}
            className="mt-16 grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-border/60 bg-border/60 sm:grid-cols-3"
          >
            {hero.stats.map((s) => (
              <div key={s.label} className="bg-background/80 p-5 backdrop-blur">
                <dt className="font-display text-2xl font-semibold text-primary">{s.value}</dt>
                <dd className="mt-1 text-xs leading-snug text-muted-foreground">{s.label}</dd>
              </div>
            ))}
          </motion.dl>
        </motion.div>
      </div>

      {/* Scroll cue */}
      <motion.button
        onClick={() => document.getElementById('origin')?.scrollIntoView({ behavior: 'smooth' })}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4 }}
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-muted-foreground transition-colors hover:text-primary sm:flex"
        aria-label="Scroll to begin"
      >
        <span className="font-mono text-[10px] uppercase tracking-[0.3em]">Scroll</span>
        <span className="flex h-9 w-5 items-start justify-center rounded-full border border-current p-1">
          <motion.span
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
            className="h-1.5 w-1 rounded-full bg-current"
          />
        </span>
      </motion.button>
    </section>
  )
}
