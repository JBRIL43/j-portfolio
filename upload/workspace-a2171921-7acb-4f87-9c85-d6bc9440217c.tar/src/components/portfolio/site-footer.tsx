'use client'

import * as React from 'react'
import { Sunrise, ArrowUp } from 'lucide-react'
import { chapters, identity } from '@/lib/portfolio-data'

export function SiteFooter() {
  const go = (id: string) =>
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })

  return (
    <footer className="mt-auto border-t border-border/60 bg-background">
      <div className="mx-auto max-w-6xl px-5 py-12 sm:px-8 sm:py-16">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr]">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5">
              <span className="relative flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary ring-1 ring-primary/30">
                <Sunrise className="h-4 w-4" />
              </span>
              <div className="flex flex-col leading-none">
                <span className="font-display text-base font-semibold">The Builder&apos;s Dawn</span>
                <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                  {identity.name} · {identity.field}
                </span>
              </div>
            </div>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
              A story of becoming — technology, leadership, creativity, and community, told as
              one continuous journey.
            </p>
          </div>

          {/* Chapters */}
          <div>
            <div className="mb-4 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              Chapters
            </div>
            <ul className="grid grid-cols-2 gap-x-6 gap-y-2">
              {chapters.map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => go(c.id)}
                    className="group flex items-baseline gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
                  >
                    <span className="font-mono text-[10px] text-primary/50">{c.index}</span>
                    {c.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <div className="mb-4 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              Reach out
            </div>
            <a
              href={`mailto:${identity.email}`}
              className="link-underline inline-block text-sm font-medium"
            >
              {identity.email}
            </a>
            <div className="mt-4 text-sm text-muted-foreground">{identity.location}</div>
            <div className="text-sm text-muted-foreground">{identity.university}</div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-start justify-between gap-4 border-t border-border/60 pt-6 sm:flex-row sm:items-center">
          <p className="font-mono text-xs text-muted-foreground">
            © {new Date().getFullYear()} {identity.fullName}. Built deliberately, one chapter at a time.
          </p>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="group inline-flex items-center gap-2 rounded-full border border-border/70 px-4 py-2 text-xs font-medium transition-colors hover:border-primary/50 hover:text-primary"
          >
            Back to the dawn
            <ArrowUp className="h-3.5 w-3.5 transition-transform group-hover:-translate-y-0.5" />
          </button>
        </div>
      </div>
    </footer>
  )
}
