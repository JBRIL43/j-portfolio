'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { craft } from '@/lib/portfolio-data'
import { SectionHeading } from './section-heading'
import { cn } from '@/lib/utils'

function depthOf(note: string): 'Learning' | 'Working' {
  return note.toLowerCase().includes('learning') ? 'Learning' : 'Working'
}

export function Craft() {
  const [active, setActive] = React.useState(0)
  const group = craft[active]

  return (
    <section id="craft" className="relative scroll-mt-20 py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          index="III"
          eyebrow="Craft"
          title={
            <>
              The workshop —
              <br />
              <span className="text-muted-foreground">tools grouped by what they build.</span>
            </>
          }
        />

        <p className="mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
          Skill bars lie. They flatten a decade of practice and a week of tinkering into the
          same rectangle. Instead, here are the tools I reach for, grouped by the layer of the
          work they belong to — and an honest note on where each one sits.
        </p>

        {/* Group selector */}
        <div className="mt-12 flex flex-wrap gap-2">
          {craft.map((g, i) => (
            <button
              key={g.name}
              onClick={() => setActive(i)}
              className={cn(
                'group inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition-all',
                active === i
                  ? 'border-primary bg-primary text-primary-foreground'
                  : 'border-border bg-background text-muted-foreground hover:border-primary/40 hover:text-foreground',
              )}
            >
              <span className="font-display text-base leading-none">{g.glyph}</span>
              {g.name}
              <span
                className={cn(
                  'font-mono text-[10px]',
                  active === i ? 'text-primary-foreground/70' : 'text-muted-foreground/70',
                )}
              >
                {g.tools.length}
              </span>
            </button>
          ))}
        </div>

        {/* Active group */}
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.4 }}
            className="mt-10"
          >
            <p className="mb-6 max-w-xl text-sm italic text-muted-foreground">{group.desc}</p>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {group.tools.map((t, i) => {
                const depth = depthOf(t.note)
                return (
                  <motion.div
                    key={t.name}
                    initial={{ opacity: 0, scale: 0.96 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.4, delay: i * 0.04 }}
                    className="group relative flex flex-col justify-between overflow-hidden rounded-xl border border-border/60 bg-card/50 p-5 transition-colors hover:border-primary/40"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <h4 className="font-display text-base font-semibold">{t.name}</h4>
                        <span
                          className={cn(
                            'font-mono text-[9px] uppercase tracking-[0.16em]',
                            depth === 'Learning' ? 'text-primary/80' : 'text-muted-foreground',
                          )}
                        >
                          {depth}
                        </span>
                      </div>
                      <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{t.note}</p>
                    </div>
                    <span className="mt-4 h-1 w-full overflow-hidden rounded-full bg-border">
                      <span
                        className={cn(
                          'block h-full rounded-full',
                          depth === 'Learning'
                            ? 'w-1/3 bg-primary/60'
                            : 'w-full bg-primary',
                        )}
                      />
                    </span>
                  </motion.div>
                )
              })}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  )
}
