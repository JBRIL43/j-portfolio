'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import { Sparkles, Hammer, Users, Rocket, BookOpen } from 'lucide-react'
import { journey, type Milestone } from '@/lib/portfolio-data'
import { SectionHeading } from './section-heading'

const beatConfig: Record<Milestone['beat'], { icon: React.ElementType; label: string }> = {
  spark: { icon: Sparkles, label: 'Spark' },
  build: { icon: Hammer, label: 'Build' },
  lead: { icon: Users, label: 'Lead' },
  ship: { icon: Rocket, label: 'Ship' },
  learn: { icon: BookOpen, label: 'Learn' },
}

export function Journey() {
  return (
    <section
      id="journey"
      className="relative scroll-mt-20 border-y border-border/50 bg-secondary/30 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          index="II"
          eyebrow="Journey"
          title={
            <>
              The path so far —
              <br />
              <span className="text-muted-foreground">told as beats, not dates.</span>
            </>
          }
        />

        <p className="mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
          A résumé lists what happened. A journey explains why each step led to the next.
          Here&apos;s the throughline — the moments where the direction changed.
        </p>

        {/* Timeline */}
        <div className="relative mt-16 pl-8 sm:pl-12">
          {/* Vertical line */}
          <div className="absolute left-[11px] top-2 h-[calc(100%-2rem)] w-px bg-gradient-to-b from-primary via-primary/40 to-transparent sm:left-[15px]" />

          <div className="space-y-12">
            {journey.map((m, i) => {
              const cfg = beatConfig[m.beat]
              const Icon = cfg.icon
              return (
                <motion.div
                  key={m.title}
                  initial={{ opacity: 0, x: -16 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: '-100px' }}
                  transition={{ duration: 0.6, delay: 0.05 }}
                  className="relative"
                >
                  {/* Node */}
                  <div className="absolute -left-8 top-1 sm:-left-12">
                    <span className="relative flex h-6 w-6 items-center justify-center rounded-full bg-background ring-1 ring-primary/40 sm:h-8 sm:w-8">
                      <span className="absolute inset-0 rounded-full bg-primary/10 blur-sm" />
                      <Icon className="relative h-3 w-3 text-primary sm:h-4 sm:w-4" />
                    </span>
                  </div>

                  <div className="group rounded-2xl border border-border/60 bg-card/60 p-6 transition-colors hover:border-primary/40 sm:p-7">
                    <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
                      <div className="flex items-baseline gap-3">
                        <span className="font-mono text-xs uppercase tracking-[0.18em] text-primary">
                          {m.year}
                        </span>
                        <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                          · {cfg.label}
                        </span>
                      </div>
                      <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                        {m.phase}
                      </span>
                    </div>
                    <h3 className="mt-3 font-display text-xl font-semibold leading-tight sm:text-2xl">
                      {m.title}
                    </h3>
                    <p className="mt-3 text-sm leading-relaxed text-muted-foreground sm:text-base">
                      {m.story}
                    </p>
                  </div>
                </motion.div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
