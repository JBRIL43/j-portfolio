'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import { Compass, Telescope, ArrowRight } from 'lucide-react'
import { horizon } from '@/lib/portfolio-data'
import { SectionHeading } from './section-heading'

export function Horizon() {
  return (
    <section
      id="horizon"
      className="relative scroll-mt-20 border-y border-border/50 bg-secondary/30 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading index="VI" eyebrow="Horizon" title={horizon.title} />
        <p className="mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
          {horizon.intro}
        </p>

        <div className="mt-16 grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
          {/* Now learning */}
          <div>
            <div className="mb-6 flex items-center gap-3">
              <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 text-primary ring-1 ring-primary/25">
                <Compass className="h-4 w-4" />
              </span>
              <h3 className="font-display text-xl font-semibold">Currently learning</h3>
            </div>
            <div className="space-y-3">
              {horizon.nowLearning.map((l, i) => (
                <motion.div
                  key={l.name}
                  initial={{ opacity: 0, x: -16 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: '-80px' }}
                  transition={{ duration: 0.5, delay: i * 0.08 }}
                  className="group flex items-center gap-4 rounded-2xl border border-border/60 bg-background/60 p-4 transition-colors hover:border-primary/40"
                >
                  <span className="font-mono text-xs text-primary/60">{String(i + 1).padStart(2, '0')}</span>
                  <div className="flex-1">
                    <div className="font-display text-base font-semibold">{l.name}</div>
                    <div className="text-xs text-muted-foreground">{l.note}</div>
                  </div>
                  <span className="h-2 w-2 rounded-full bg-primary/60 transition-transform group-hover:scale-150" />
                </motion.div>
              ))}
            </div>
          </div>

          {/* Vision */}
          <div>
            <div className="mb-6 flex items-center gap-3">
              <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 text-primary ring-1 ring-primary/25">
                <Telescope className="h-4 w-4" />
              </span>
              <h3 className="font-display text-xl font-semibold">Who I&apos;m becoming</h3>
            </div>
            <div className="grid gap-px overflow-hidden rounded-2xl border border-border/60 bg-border/60 sm:grid-cols-2">
              {horizon.vision.map((v, i) => (
                <motion.div
                  key={v.role}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true, margin: '-60px' }}
                  transition={{ duration: 0.5, delay: (i % 2) * 0.08 }}
                  className="bg-background p-5"
                >
                  <div className="flex items-center gap-2">
                    <ArrowRight className="h-3.5 w-3.5 text-primary" />
                    <h4 className="font-display text-base font-semibold">{v.role}</h4>
                  </div>
                  <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{v.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Closing */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6 }}
          className="mt-16 rounded-3xl border border-primary/20 bg-gradient-to-br from-primary/5 to-transparent p-8 sm:p-12"
        >
          <p className="font-display text-xl font-medium leading-snug text-balance sm:text-2xl">
            {horizon.closing}
          </p>
        </motion.div>
      </div>
    </section>
  )
}
