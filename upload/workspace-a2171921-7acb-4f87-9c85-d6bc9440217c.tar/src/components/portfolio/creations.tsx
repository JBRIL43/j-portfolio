'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import { ArrowUpRight, Target, Compass, Sparkle } from 'lucide-react'
import { projects, type Project } from '@/lib/portfolio-data'
import { SectionHeading } from './section-heading'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { cn } from '@/lib/utils'

const statusStyles: Record<Project['status'], string> = {
  Shipped: 'bg-primary/10 text-primary ring-primary/25',
  Ongoing: 'bg-emerald-500/10 text-emerald-500 ring-emerald-500/25',
  Concept: 'bg-muted text-muted-foreground ring-border',
}

function Narrative({ project }: { project: Project }) {
  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-[0.18em] text-primary">
          <Target className="h-3.5 w-3.5" /> The problem
        </div>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{project.problem}</p>
      </div>
      <div>
        <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-[0.18em] text-primary">
          <Compass className="h-3.5 w-3.5" /> The approach
        </div>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{project.approach}</p>
      </div>
      <div>
        <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-[0.18em] text-primary">
          <Sparkle className="h-3.5 w-3.5" /> The impact
        </div>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{project.impact}</p>
      </div>
    </div>
  )
}

export function Creations() {
  const featured = projects.find((p) => p.featured)!
  const rest = projects.filter((p) => !p.featured)

  return (
    <section id="creations" className="relative scroll-mt-20 py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          index="V"
          eyebrow="Creations"
          title={
            <>
              What I&apos;ve built —
              <br />
              <span className="text-muted-foreground">each one a problem I couldn&apos;t ignore.</span>
            </>
          }
        />

        {/* Featured project */}
        <motion.article
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7 }}
          className="mt-12 overflow-hidden rounded-3xl border border-border/60 bg-card"
        >
          <div className="grid lg:grid-cols-[0.9fr_1.1fr]">
            {/* Visual / meta side */}
            <div className="relative flex flex-col justify-between gap-6 border-b border-border/60 bg-secondary/40 p-8 lg:border-b-0 lg:border-r sm:p-10">
              <div className="absolute -right-8 -top-8 select-none font-display text-[10rem] leading-none text-primary/5">
                {featured.glyph}
              </div>
              <div className="relative">
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className={cn(
                      'rounded-full px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-[0.14em] ring-1',
                      statusStyles[featured.status],
                    )}
                  >
                    {featured.status}
                  </span>
                  <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                    {featured.category} · {featured.year}
                  </span>
                </div>
                <h3 className="mt-4 font-display text-2xl font-semibold leading-tight sm:text-3xl">
                  {featured.name}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {featured.summary}
                </p>
                {featured.links?.length ? (
                  <div className="mt-5 flex flex-wrap gap-2">
                    {featured.links.map((l) => (
                      <a
                        key={l.href}
                        href={l.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={cn(
                          'group inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-medium transition-transform hover:scale-[1.03]',
                          l.kind === 'live'
                            ? 'bg-primary text-primary-foreground'
                            : 'border border-border bg-background text-foreground hover:border-primary/50 hover:text-primary',
                        )}
                      >
                        {l.label}
                        <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                      </a>
                    ))}
                  </div>
                ) : null}
              </div>
              <div className="relative flex flex-wrap gap-2">
                {featured.stack.map((s) => (
                  <span
                    key={s}
                    className="rounded-md border border-border/70 bg-background px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.1em] text-muted-foreground"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>

            {/* Narrative side */}
            <div className="p-8 sm:p-10">
              <Narrative project={featured} />
            </div>
          </div>
        </motion.article>

        {/* Other projects */}
        <div className="mt-8 grid gap-5 md:grid-cols-2">
          {rest.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
            >
              <Dialog>
                <DialogTrigger asChild>
                  <button className="group flex h-full w-full flex-col rounded-2xl border border-border/60 bg-card/50 p-6 text-left transition-all hover:-translate-y-1 hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5">
                    <div className="flex items-start justify-between">
                      <span className="font-display text-3xl text-primary/70">{p.glyph}</span>
                      <ArrowUpRight className="h-4 w-4 text-muted-foreground transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary" />
                    </div>
                    <div className="mt-4 flex flex-wrap items-center gap-2">
                      <span
                        className={cn(
                          'rounded-full px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.14em] ring-1',
                          statusStyles[p.status],
                        )}
                      >
                        {p.status}
                      </span>
                      <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
                        {p.year}
                      </span>
                    </div>
                    <h4 className="mt-3 font-display text-lg font-semibold leading-tight">{p.name}</h4>
                    <p className="mt-2 flex-1 text-xs leading-relaxed text-muted-foreground">
                      {p.summary}
                    </p>
                    <div className="mt-4 flex flex-wrap gap-1.5">
                      {p.stack.slice(0, 3).map((s) => (
                        <span
                          key={s}
                          className="rounded border border-border/60 px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-[0.08em] text-muted-foreground"
                        >
                          {s}
                        </span>
                      ))}
                    </div>
                  </button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <div className="flex items-center gap-2">
                      <span className="font-display text-2xl text-primary">{p.glyph}</span>
                      <span
                        className={cn(
                          'rounded-full px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.14em] ring-1',
                          statusStyles[p.status],
                        )}
                      >
                        {p.status}
                      </span>
                    </div>
                    <DialogTitle className="font-display text-2xl">{p.name}</DialogTitle>
                    <p className="text-sm text-muted-foreground">
                      {p.category} · {p.year}
                    </p>
                  </DialogHeader>
                  <div className="mt-2">
                    <Narrative project={p} />
                    <div className="mt-6 flex flex-wrap gap-2">
                      {p.stack.map((s) => (
                        <span
                          key={s}
                          className="rounded-md border border-border bg-secondary/40 px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.1em] text-muted-foreground"
                        >
                          {s}
                        </span>
                      ))}
                    </div>
                    {p.links?.length ? (
                      <div className="mt-4 flex flex-wrap gap-2">
                        {p.links.map((l) => (
                          <a
                            key={l.href}
                            href={l.href}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="group inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-xs font-medium text-primary-foreground transition-transform hover:scale-[1.03]"
                          >
                            {l.label}
                            <ArrowUpRight className="h-3.5 w-3.5" />
                          </a>
                        ))}
                      </div>
                    ) : null}
                  </div>
                </DialogContent>
              </Dialog>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
