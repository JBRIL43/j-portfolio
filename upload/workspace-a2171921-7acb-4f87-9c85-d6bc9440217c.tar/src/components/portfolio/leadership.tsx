'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import { Megaphone, Quote } from 'lucide-react'
import { leadership } from '@/lib/portfolio-data'
import { SectionHeading } from './section-heading'

export function Leadership() {
  return (
    <section
      id="leadership"
      className="relative scroll-mt-20 border-y border-border/50 bg-secondary/30 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading index="IV" eyebrow="Leadership" title="Building people, not just products." />

        {/* Role header */}
        <div className="mt-12 grid gap-10 lg:grid-cols-[1fr_1.2fr] lg:gap-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6 }}
            className="relative overflow-hidden rounded-3xl border border-border/60 bg-card p-8"
          >
            <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-primary/10 blur-3xl" />
            <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary ring-1 ring-primary/25">
              <Megaphone className="h-5 w-5" />
            </span>
            <div className="mt-6 font-mono text-xs uppercase tracking-[0.18em] text-primary">
              {leadership.duration}
            </div>
            <h3 className="mt-2 font-display text-3xl font-semibold leading-tight">
              {leadership.role}
            </h3>
            <div className="mt-1 text-lg text-muted-foreground">@ {leadership.org}</div>
            <div className="mt-6 h-px w-full bg-border" />
            <p className="mt-6 text-sm leading-relaxed text-muted-foreground">{leadership.intro}</p>
          </motion.div>

          {/* Pillars */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {leadership.pillars.map((p, i) => (
              <motion.div
                key={p.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="flex flex-col rounded-2xl border border-border/60 bg-background/60 p-5"
              >
                <div className="flex items-start justify-between gap-3">
                  <h4 className="font-display text-base font-semibold leading-tight">{p.title}</h4>
                  <span className="shrink-0 rounded-full bg-primary/10 px-2.5 py-0.5 font-mono text-[9px] uppercase tracking-[0.14em] text-primary">
                    {p.metric}
                  </span>
                </div>
                <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{p.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Reflection */}
        <motion.figure
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6 }}
          className="mt-16 overflow-hidden rounded-3xl border border-primary/20 bg-primary/5 p-8 sm:p-12"
        >
          <Quote className="h-7 w-7 text-primary/50" />
          <blockquote className="mt-4 font-display text-xl font-medium leading-snug text-balance sm:text-2xl">
            “{leadership.reflection}”
          </blockquote>
          <figcaption className="mt-4 font-mono text-xs uppercase tracking-[0.18em] text-muted-foreground">
            — On what leadership actually is
          </figcaption>
        </motion.figure>
      </div>
    </section>
  )
}
