'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import { origin } from '@/lib/portfolio-data'
import { SectionHeading } from './section-heading'

export function Origin() {
  return (
    <section id="origin" className="relative scroll-mt-20 py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          index={origin.eyebrow.split(' · ')[0].replace('Chapter ', '')}
          eyebrow="Origin"
          title={origin.title}
        />

        {/* Body + currents */}
        <div className="mt-12 grid gap-12 lg:grid-cols-[1fr_1.1fr] lg:gap-16">
          <div className="space-y-5">
            {origin.body.map((p, i) => (
              <motion.p
                key={i}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.6, delay: i * 0.08 }}
                className="text-base leading-relaxed text-muted-foreground sm:text-lg"
              >
                {p}
              </motion.p>
            ))}
          </div>

          {/* Four currents */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {origin.currents.map((c, i) => (
              <motion.div
                key={c.name}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                className="group relative overflow-hidden rounded-2xl border border-border/70 bg-card/50 p-6 transition-colors hover:border-primary/40"
              >
                <div className="absolute -right-6 -top-6 font-display text-7xl text-primary/5 transition-colors group-hover:text-primary/10">
                  {c.glyph}
                </div>
                <span className="font-display text-3xl text-primary">{c.glyph}</span>
                <h3 className="mt-3 font-display text-xl font-semibold">{c.name}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{c.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Principles */}
        <div className="mt-24">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="mb-8 flex items-center gap-4"
          >
            <span className="font-mono text-xs uppercase tracking-[0.22em] text-primary">
              Operating principles
            </span>
            <span className="h-px flex-1 bg-border" />
          </motion.div>

          <div className="grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-border/60 bg-border/60 sm:grid-cols-2 lg:grid-cols-3">
            {origin.principles.map((p, i) => (
              <motion.div
                key={p.title}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
                className="group bg-background p-6 transition-colors hover:bg-accent/40"
              >
                <div className="mb-3 font-mono text-xs text-primary/70">
                  {String(i + 1).padStart(2, '0')}
                </div>
                <h4 className="font-display text-lg font-semibold leading-tight">{p.title}</h4>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
