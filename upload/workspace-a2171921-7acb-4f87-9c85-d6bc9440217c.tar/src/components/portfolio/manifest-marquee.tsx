'use client'

import { manifest } from '@/lib/portfolio-data'

export function ManifestMarquee() {
  const items = [...manifest, ...manifest, ...manifest]
  return (
    <div className="relative overflow-hidden border-y border-border/50 bg-primary/5 py-5">
      <div className="flex w-max animate-marquee gap-10 whitespace-nowrap">
        {items.map((m, i) => (
          <span key={i} className="flex items-center gap-10">
            <span className="font-display text-xl font-semibold tracking-tight text-primary/80 sm:text-2xl">
              {m}
            </span>
            <span className="text-primary/30">✦</span>
          </span>
        ))}
      </div>
    </div>
  )
}
